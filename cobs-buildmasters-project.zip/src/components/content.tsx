import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import type { ReactNode } from "react";

import { Button } from "@/components/ui/button";

export function PageHero({ eyebrow, title, description, image, imageAlt }: { eyebrow: string; title: string; description: string; image: string; imageAlt: string }) {
  return <section className="relative min-h-[460px] overflow-hidden bg-primary text-primary-foreground"><img src={image} alt={imageAlt} className="absolute inset-0 h-full w-full object-cover opacity-60" width={1400} height={900} /><div className="absolute inset-0 bg-hero-overlay" /><div className="site-container relative flex min-h-[460px] items-end py-16 sm:py-20"><div className="max-w-3xl border-l-2 border-accent pl-5 sm:pl-7"><p className="eyebrow text-accent">{eyebrow}</p><h1 className="display-title mt-4 text-5xl sm:text-6xl lg:text-7xl">{title}</h1><p className="mt-5 max-w-2xl text-base leading-8 text-primary-foreground/80 sm:text-lg">{description}</p></div></div></section>;
}

export function SectionHeading({ eyebrow, title, body, inverse = false }: { eyebrow: string; title: string; body?: string; inverse?: boolean }) {
  return <div className="max-w-3xl"><p className="eyebrow text-accent">{eyebrow}</p><h2 className={`section-title mt-3 ${inverse ? "text-primary-foreground" : "text-foreground"}`}>{title}</h2>{body && <p className={`mt-5 max-w-2xl text-base leading-8 ${inverse ? "text-primary-foreground/70" : "text-muted-foreground"}`}>{body}</p>}</div>;
}

export function QuoteBand() {
  return <section className="border-y border-accent/25 bg-primary text-primary-foreground"><div className="site-container grid gap-7 py-14 md:grid-cols-[1fr_auto] md:items-center"><div><p className="eyebrow text-accent">Ready to build?</p><h2 className="mt-2 font-display text-3xl font-extrabold uppercase sm:text-4xl">Planning a Construction Project?</h2><p className="mt-3 max-w-2xl leading-7 text-primary-foreground/70">Tell us what you need and our team will help you with the right materials or equipment enquiry.</p></div><Button asChild variant="gold" size="lg"><Link to="/contact">Request a Quote <ArrowRight size={18} /></Link></Button></div></section>;
}

export function SpecList({ children }: { children: ReactNode }) {
  return <div className="mt-5 border-t border-border pt-4 text-sm leading-7 text-muted-foreground">{children}</div>;
}