import { Link, useRouterState } from "@tanstack/react-router";
import { ArrowUpRight, Mail, MapPin, Menu, MessageCircle, Phone, X } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";

import logoAsset from "@/assets/cobs-logo.jpeg.asset.json";
import { Button } from "@/components/ui/button";
import { CONTACT } from "@/lib/site-data";

const nav = [
  { label: "Home", to: "/" as const },
  { label: "About", to: "/about" as const },
  { label: "Products", to: "/products" as const },
  { label: "Equipment Rental", to: "/equipment-rental" as const },
  { label: "Gallery", to: "/gallery" as const },
  { label: "Contact", to: "/contact" as const },
];

export function SiteShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  useEffect(() => {
    setOpen(false);
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [pathname]);
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-50 border-b border-border/70 bg-background/95 shadow-sm backdrop-blur">
        <div className="hidden bg-primary text-primary-foreground lg:block"><div className="site-container flex h-9 items-center justify-end gap-6 text-xs font-semibold"><a href={CONTACT.phoneHref} className="inline-flex items-center gap-2 hover:text-accent"><Phone size={13} />{CONTACT.phone}</a><a href={CONTACT.emailHref} className="inline-flex items-center gap-2 hover:text-accent"><Mail size={13} />{CONTACT.email}</a><span className="inline-flex items-center gap-2 text-primary-foreground/70"><MapPin size={13} />{CONTACT.location}</span></div></div>
        <div className="site-container grid h-24 grid-cols-[minmax(0,1fr)_auto] items-center gap-4 lg:h-24">
          <Link to="/" className="flex min-w-0 items-center gap-3" aria-label="Cobs Buildmasters home">
            <img src={logoAsset.url} alt="Cobs Buildmasters Ltd" className="h-20 w-40 shrink-0 object-contain object-left sm:w-44" width={1200} height={630} />
          </Link>
          <nav className="hidden items-center gap-1 lg:flex" aria-label="Main navigation">
            {nav.map((item) => (
              <Link key={item.to} to={item.to} activeOptions={{ exact: item.to === "/" }} className="nav-link" activeProps={{ className: "nav-link nav-link-active" }}>{item.label}</Link>
            ))}
            <Button asChild variant="gold" size="sm" className="ml-3"><Link to="/contact">Get a Quote <ArrowUpRight size={16} /></Link></Button>
          </nav>
          <Button variant="ghost" size="icon" className="lg:hidden" aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open} onClick={() => setOpen((value) => !value)}>{open ? <X /> : <Menu />}</Button>
        </div>
        {open && (
          <nav className="border-t border-border bg-background px-5 py-5 lg:hidden" aria-label="Mobile navigation">
            <div className="grid gap-1">
              {nav.map((item) => <Link key={item.to} to={item.to} onClick={() => setOpen(false)} className="mobile-nav-link" activeProps={{ className: "mobile-nav-link bg-muted text-primary" }}>{item.label}</Link>)}
              <Button asChild variant="gold" className="mt-3"><Link to="/contact" onClick={() => setOpen(false)}>Get a Quote</Link></Button>
            </div>
          </nav>
        )}
      </header>
      <main>{children}</main>
      <footer className="bg-primary text-primary-foreground">
        <div className="site-container grid gap-10 py-14 md:grid-cols-[1.2fr_1fr_1fr]">
           <div><img src={logoAsset.url} alt="Cobs Buildmasters Ltd" className="h-28 w-56 bg-primary-foreground object-contain p-2" width={1200} height={630} /><p className="mt-5 max-w-sm text-sm leading-7 text-primary-foreground/70">Construction materials and equipment rental for building projects across Ghana.</p></div>
          <div><p className="eyebrow text-accent">Explore</p><div className="mt-4 grid gap-3 text-sm">{nav.slice(1).map((item) => <Link key={item.to} to={item.to} className="text-primary-foreground/70 hover:text-accent">{item.label}</Link>)}</div></div>
           <div><p className="eyebrow text-accent">Contact</p><address className="mt-4 space-y-3 text-sm not-italic text-primary-foreground/70"><p>{CONTACT.location}</p><p><a href={CONTACT.phoneHref} className="hover:text-accent">{CONTACT.phone}</a></p><p><a href={CONTACT.emailHref} className="break-all hover:text-accent">{CONTACT.email}</a></p></address></div>
        </div>
        <div className="border-t border-primary-foreground/15"><div className="site-container flex flex-col gap-2 py-5 text-xs text-primary-foreground/60 sm:flex-row sm:items-center sm:justify-between"><p>© 2026 Cobs Buildmasters Ltd.</p><p>Concrete blocks · Cement · Iron rods · Equipment rental</p></div></div>
      </footer>
      <a href={CONTACT.whatsappHref} target="_blank" rel="noreferrer" className="fixed bottom-5 right-5 z-40 grid h-16 w-16 place-items-center rounded-full bg-whatsapp text-whatsapp-foreground shadow-strong transition-transform hover:scale-105" aria-label={`Chat with Cobs Buildmasters on WhatsApp at ${CONTACT.whatsapp}`} title="WhatsApp Cobs Buildmasters"><MessageCircle size={28} /></a>
    </div>
  );
}