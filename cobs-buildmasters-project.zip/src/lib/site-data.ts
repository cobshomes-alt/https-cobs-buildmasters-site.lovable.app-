import blocksAsset from "@/assets/concrete-blocks.jpg.asset.json";
import cementAsset from "@/assets/cement-supply.jpg.asset.json";
import equipmentAsset from "@/assets/equipment-rental.jpg.asset.json";
import ironAsset from "@/assets/iron-rods.jpg.asset.json";
import siteAsset from "@/assets/site-team.jpg.asset.json";
import tBeamAsset from "@/assets/t-beam.jpg.asset.json";
import scaffoldingAsset from "@/assets/scaffolding.jpg.asset.json";
import pillarsAsset from "@/assets/concrete-pillars.jpg.asset.json";
import mixerAsset from "@/assets/concrete-mixer.jpg.asset.json";
import blockMachineAsset from "@/assets/block-machine.jpg.asset.json";

export const CONTACT = {
  phone: "+233594599327",
  phoneHref: "tel:+233594599327",
  whatsapp: "+233594599327",
  whatsappHref: "https://wa.me/233594599327?text=Hello%20Cobs%20Buildmasters%20Ltd%2C%20I%20would%20like%20to%20make%20an%20enquiry%20about%20your%20construction%20materials%20or%20equipment%20rental%20services.",
  email: "cobshomes@gmail.com",
  emailHref: "mailto:cobshomes@gmail.com",
  location: "Adenta New Legon, Ghana",
};

export const services = [
  { name: "Concrete Blocks", description: "Quality concrete blocks for residential, commercial and construction projects.", image: blocksAsset.url, alt: "Concrete blocks stacked at a construction materials yard in Ghana", to: "/products" as const },
  { name: "Cement", description: "Reliable cement supply for foundations, blockwork, concrete works and general construction.", image: cementAsset.url, alt: "Cement bags stocked in a construction materials warehouse", to: "/products" as const },
  { name: "Iron Rods", description: "Construction reinforcement steel for strong and durable structural work.", image: ironAsset.url, alt: "Bundled reinforcement iron rods at a construction site", to: "/products" as const },
  { name: "T-Beams (Trasacco Beams)", description: "Precast concrete T-Beams (Trasacco Beams) for building construction and structural applications.", image: tBeamAsset.url, alt: "Precast concrete T-Beams, commonly known in Ghana as Trasacco Beams, at a construction site", to: "/products" as const },
  { name: "Construction Equipment Rental", description: "Reliable construction equipment rental for contractors, developers and building projects.", image: equipmentAsset.url, alt: "Construction machinery illustrating equipment rental services in Ghana", to: "/equipment-rental" as const },
];

// Core construction materials. Specifications stay editable until confirmed.
export const products = [
  { name: "Concrete Blocks", image: blocksAsset.url, alt: "Concrete blocks supplied for residential and commercial building", description: "Quality concrete blocks for residential, commercial and construction projects.", specs: "Block types and sizes can be added when confirmed. Please enquire for current options." },
  { name: "Cement", image: cementAsset.url, alt: "Cement bags for foundations and concrete works", description: "Reliable cement supply for foundations, blockwork, concrete works and general construction.", specs: "Brands and specifications can be added when confirmed. Please enquire for current options." },
  { name: "Iron Rods", image: ironAsset.url, alt: "Reinforcement iron rods for structural construction", description: "Construction reinforcement steel for strong and durable structural work.", specs: "Sizes and specifications can be added when confirmed. Please enquire for current options." },
  { name: "T-Beam (Trasacco Beam)", image: tBeamAsset.url, alt: "Precast concrete T-Beam, commonly known in Ghana as Trasacco Beam", description: "T-Beams (Trasacco Beams) are precast concrete structural components used in building construction. They provide a practical structural solution for floor and building systems and are suitable for a range of construction projects.", specs: "Lengths, dimensions and structural details can be added when confirmed. Please enquire for current options." },
];

// Equipment and site items. Set supply to "Rental" or "Supply" once confirmed.
export const equipmentItems = [
  { name: "Scaffolding", image: scaffoldingAsset.url, alt: "Steel scaffolding erected around a building under construction", supply: "Rental", description: "Scaffolding support for building and construction projects.", specs: "Heights, quantities and hire terms available on enquiry." },
  { name: "Concrete Pillars / Columns", image: pillarsAsset.url, alt: "Precast concrete pillars and columns stacked at a construction yard", supply: "Supply or rental on enquiry", description: "Concrete pillars and columns for structural construction work.", specs: "Whether an item is supplied or rented is confirmed on enquiry." },
  { name: "Concrete Mixers", image: mixerAsset.url, alt: "Concrete mixer machine on a construction site", supply: "Rental", description: "Concrete mixers for site concrete works.", specs: "Machine details and rental periods available on enquiry." },
  { name: "Block-Making Machines", image: blockMachineAsset.url, alt: "Industrial block-making machine producing concrete blocks", supply: "Rental", description: "Block-making machinery for block production requirements.", specs: "Machine details and rental periods available on enquiry." },
  { name: "Construction Equipment", image: equipmentAsset.url, alt: "Construction machinery available for building projects", supply: "Rental", description: "General construction equipment for building projects.", specs: "Equipment names and availability confirmed on enquiry." },
  { name: "Other Building Equipment", image: siteAsset.url, alt: "Construction team working with building equipment on site", supply: "On enquiry", description: "Additional building and construction equipment can be listed here as details are confirmed.", specs: "Equipment name, photograph, description, specifications, rental rate and availability can be added later." },
];

export const galleryItems = [
  { label: "Concrete blocks", image: blocksAsset.url, alt: "Concrete blocks ready for a Ghana building project" },
  { label: "Cement supply", image: cementAsset.url, alt: "Pallets of cement bags in stock" },
  { label: "Reinforcement steel", image: ironAsset.url, alt: "Iron rods prepared for structural construction" },
  { label: "Equipment rental", image: equipmentAsset.url, alt: "Construction excavator at an active site" },
  { label: "Site operations", image: siteAsset.url, alt: "Ghanaian construction team reviewing building plans" },
  { label: "Completed projects", image: blocksAsset.url, alt: "Illustrative construction materials image reserved for future completed project photography" },
];

export const whatsappMessage = encodeURIComponent(
  "Hello Cobs Buildmasters Ltd, I would like to make an enquiry about your construction materials/equipment.",
);