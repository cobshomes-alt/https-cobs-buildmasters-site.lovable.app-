import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, BadgeCheck, Handshake, MessageCircle, PackageCheck, WalletCards } from "lucide-react";

import heroAsset from "@/assets/cobs-hero.jpg.asset.json";
import siteAsset from "@/assets/site-team.jpg.asset.json";
import { QuoteBand, SectionHeading } from "@/components/content";
import { Button } from "@/components/ui/button";
import { services } from "@/lib/site-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Construction Materials Ghana | Cobs Buildmasters" },
      { name: "description", content: "Cobs Buildmasters supplies concrete blocks, cement, iron rods and construction equipment rental for building projects in Ghana." },
      { property: "og:title", content: "Cobs Buildmasters Ltd | Building Materials Ghana" },
      { property: "og:description", content: "Quality construction materials and reliable equipment rental for projects of every scale." },
      { property: "og:type", content: "website" }, { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
    ], links: [{ rel: "canonical", href: "/" }],
  }),
  component: Index,
});

// IMPORTANT: Replace this placeholder. See ./README.md for routing conventions.
function Index() {
  const strengths = [
    { title: "Quality Materials", text: "Reliable construction materials for your project.", icon: BadgeCheck },
    { title: "Reliable Supply", text: "Dependable service for construction projects.", icon: PackageCheck },
    { title: "Competitive Value", text: "Professional service with a focus on value.", icon: WalletCards },
    { title: "Customer-Focused Service", text: "Making it easy to enquire, order and get the support customers need.", icon: Handshake },
  ];
  return <>
    <section className="relative min-h-[680px] overflow-hidden bg-primary text-primary-foreground sm:min-h-[560px]">
      <img src={heroAsset.url} alt="Construction site in Ghana with concrete blocks, steel and equipment" className="absolute inset-0 h-full w-full object-cover object-[62%_center]" width={1920} height={1088} fetchPriority="high" />
      <div className="absolute inset-0 bg-hero-overlay" />
      <div className="site-container relative flex min-h-[680px] items-center py-14 sm:min-h-[560px]"><div className="max-w-4xl border-l-2 border-accent pl-5 sm:pl-7"><p className="eyebrow text-accent">Construction materials & equipment · Ghana</p><h1 className="display-title mt-5 text-5xl sm:text-7xl lg:text-[5.5rem]">Building Ghana with Strength and Reliability.</h1><p className="mt-6 max-w-2xl text-base leading-8 text-primary-foreground/80 sm:text-lg">Quality construction materials and reliable equipment rental for residential, commercial and development projects.</p><div className="mt-8 flex flex-col gap-3 sm:flex-row"><Button asChild variant="gold" size="lg"><Link to="/contact">Request a Quote <ArrowRight size={18} /></Link></Button><Button asChild variant="light" size="lg"><a href="https://wa.me/233594599327?text=Hello%20Cobs%20Buildmasters%20Ltd%2C%20I%20would%20like%20to%20make%20an%20enquiry%20about%20your%20construction%20materials%20or%20equipment%20rental%20services." target="_blank" rel="noreferrer"><MessageCircle size={18} /> WhatsApp Us</a></Button></div></div></div>
    </section>
    <section className="py-20 sm:py-28"><div className="site-container"><div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between"><SectionHeading eyebrow="Our core offering" title="What We Supply & Rent" body="Essential materials and dependable equipment support for residential and commercial construction across Ghana." /><Button asChild variant="outline"><Link to="/products">View Catalogue <ArrowRight size={17} /></Link></Button></div><div className="mt-12 grid gap-5 md:grid-cols-2">{services.map((service, index) => <article key={service.name} className="group grid min-h-[420px] overflow-hidden bg-primary text-primary-foreground sm:grid-cols-[1fr_1.05fr]"><div className="flex flex-col justify-between p-7"><p className="font-display text-5xl font-bold text-accent/50">0{index + 1}</p><div><h3 className="font-display text-3xl font-bold uppercase">{service.name}</h3><p className="mt-3 text-sm leading-7 text-primary-foreground/70">{service.description}</p><Link to={service.to} className="mt-6 inline-flex items-center gap-2 text-xs font-extrabold uppercase text-accent">Learn more <ArrowRight size={15} /></Link></div></div><img src={service.image} alt={service.alt} loading="lazy" width={1200} height={900} className="h-full min-h-56 w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]" /></article>)}</div></div></section>
    <section className="bg-primary py-20 text-primary-foreground sm:py-28"><div className="site-container grid gap-12 lg:grid-cols-2 lg:items-center"><img src={siteAsset.url} alt="Construction team reviewing project plans in Ghana" loading="lazy" width={1400} height={900} className="aspect-[4/3] h-full w-full object-cover" /><div><SectionHeading eyebrow="About Cobs" title="Built on Quality. Driven by Reliability." inverse body="Cobs Buildmasters Ltd supplies construction materials and provides construction equipment rental services to builders, contractors, developers and individuals in Ghana." /><p className="mt-6 leading-8 text-primary-foreground/70">We make it straightforward to enquire about the materials or equipment support required for residential, commercial and development projects.</p><Button asChild variant="light" className="mt-8"><Link to="/about">About Our Company <ArrowRight size={17} /></Link></Button></div></div></section>
    <section className="py-20 sm:py-28"><div className="site-container"><SectionHeading eyebrow="Why Cobs" title="A Stronger Supply Partner" /><div className="mt-12 grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-4">{strengths.map(({ title, text, icon: Icon }) => <article key={title} className="bg-background p-7"><Icon className="text-accent" size={30} strokeWidth={1.8} /><h3 className="mt-8 font-display text-2xl font-bold uppercase">{title}</h3><p className="mt-3 text-sm leading-7 text-muted-foreground">{text}</p></article>)}</div></div></section>
    <QuoteBand />
  </>;
}
