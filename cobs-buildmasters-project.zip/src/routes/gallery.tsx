import { createFileRoute } from "@tanstack/react-router";

import heroAsset from "@/assets/cobs-hero.jpg.asset.json";
import { PageHero, QuoteBand, SectionHeading } from "@/components/content";
import { galleryItems } from "@/lib/site-data";

export const Route = createFileRoute("/gallery")({ head: () => ({ meta: [
    { title: "Construction Gallery Ghana | Cobs Buildmasters" }, { name: "description", content: "Browse illustrative concrete blocks, cement, iron rods, construction equipment and site imagery for Cobs Buildmasters Ltd in Ghana." }, { property: "og:title", content: "Cobs Buildmasters Construction Gallery" }, { property: "og:description", content: "Construction materials, machinery and site imagery prepared for the Cobs Buildmasters gallery." }, { property: "og:type", content: "website" }, { property: "og:url", content: "/gallery" }, { name: "twitter:card", content: "summary_large_image" },
], links: [{ rel: "canonical", href: "/gallery" }] }), component: GalleryPage });

function GalleryPage() {
  return <><PageHero eyebrow="Product & project gallery" title="Built for the Work on Site" description="A visual look at construction materials, equipment and building environments in Ghana." image={heroAsset.url} imageAlt="Active construction project with concrete structure in Ghana" /><section className="py-20 sm:py-28"><div className="site-container"><SectionHeading eyebrow="Gallery" title="Materials in Motion" body="The current images are illustrative and can be replaced with Cobs Buildmasters product, equipment, construction site and completed project photographs as they are provided." /><div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-12">{galleryItems.map((item, index) => <figure key={item.label} className={`group relative overflow-hidden bg-primary ${index % 3 === 0 ? "lg:col-span-7" : "lg:col-span-5"}`}><img src={item.image} alt={item.alt} width={index === 4 ? 1400 : 1200} height={900} loading="lazy" className="aspect-[4/3] h-full w-full object-cover transition duration-500 group-hover:scale-[1.02]" /><figcaption className="absolute inset-x-0 bottom-0 bg-hero-overlay px-5 py-5 font-display text-2xl font-bold uppercase text-primary-foreground">{item.label}</figcaption></figure>)}</div></div></section><QuoteBand /></>;
}