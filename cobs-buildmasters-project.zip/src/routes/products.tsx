import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";

import blocksAsset from "@/assets/concrete-blocks.jpg.asset.json";
import { PageHero, QuoteBand, SectionHeading, SpecList } from "@/components/content";
import { Button } from "@/components/ui/button";
import { products } from "@/lib/site-data";

export const Route = createFileRoute("/products")({ head: () => ({ meta: [
  { title: "Building Materials Ghana | Blocks, Cement, Rods, T-Beams" }, { name: "description", content: "Browse concrete blocks, cement, reinforcement iron rods and precast T-Beams (Trasacco beams) supplied by Cobs Buildmasters in Ghana." }, { property: "og:title", content: "Construction Materials | Cobs Buildmasters" }, { property: "og:description", content: "Request current pricing for concrete blocks, cement, iron rods and T-Beams in Ghana." }, { property: "og:type", content: "website" }, { property: "og:url", content: "/products" }, { name: "twitter:card", content: "summary_large_image" },
], links: [{ rel: "canonical", href: "/products" }] }), component: ProductsPage });

function ProductsPage() {
  return <><PageHero eyebrow="Product catalogue" title="Materials for Solid Construction" description="Concrete blocks, cement, iron rods and precast T-Beams for residential, commercial and development projects in Ghana." image={blocksAsset.url} imageAlt="Concrete blocks at a Ghana construction materials yard" /><section className="py-20 sm:py-28"><div className="site-container"><SectionHeading eyebrow="What we supply" title="Construction Materials" body="Tell us your required sizes, specifications and quantities so our team can respond with suitable options and current pricing." /><div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{products.map((product) => <article key={product.name} className="border border-border bg-card shadow-sm transition-shadow hover:shadow-strong"><img src={product.image} alt={product.alt} width={1200} height={900} loading="lazy" className="aspect-[4/3] w-full object-cover" /><div className="p-6"><h2 className="font-display text-3xl font-bold uppercase">{product.name}</h2><p className="mt-3 text-sm leading-7 text-muted-foreground">{product.description}</p><div className="mt-6"><p className="eyebrow text-accent">Specifications</p><SpecList>{product.specs}</SpecList></div><Button asChild variant="primary" className="mt-6 w-full"><Link to="/contact" search={{ product: product.name }}>Request Price <ArrowRight size={17} /></Link></Button></div></article>)}</div></div></section><QuoteBand /></>;
}