import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Building2, HardHat, House, Users } from "lucide-react";

import heroAsset from "@/assets/cobs-hero.jpg.asset.json";
import siteAsset from "@/assets/site-team.jpg.asset.json";
import videoAsset from "@/assets/cobs-logo-animation.mp4.asset.json";
import { PageHero, QuoteBand, SectionHeading } from "@/components/content";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/about")({
  head: () => ({ meta: [
    { title: "About Cobs Buildmasters | Ghana Construction Supply" },
    { name: "description", content: "Cobs Buildmasters supplies construction materials and provides equipment rental services to builders, contractors, developers and individuals in Ghana." },
    { property: "og:title", content: "About Cobs Buildmasters Ltd" }, { property: "og:description", content: "Built on quality and driven by reliable service for Ghana's construction sector." }, { property: "og:type", content: "website" }, { property: "og:url", content: "/about" }, { name: "twitter:card", content: "summary_large_image" },
  ], links: [{ rel: "canonical", href: "/about" }] }), component: AboutPage,
});

function AboutPage() {
  const customers = [{ label: "Property developers", icon: Building2 }, { label: "Contractors & engineers", icon: HardHat }, { label: "Construction companies", icon: Users }, { label: "Homeowners & builders", icon: House }];
  return <><PageHero eyebrow="Our company" title="Built on Quality. Driven by Reliability." description="Construction materials and equipment rental support for the people building across Ghana." image={heroAsset.url} imageAlt="Modern concrete construction project in Ghana" />
    <section className="py-20 sm:py-28"><div className="site-container grid gap-14 lg:grid-cols-[1.1fr_.9fr] lg:items-center"><div><SectionHeading eyebrow="Cobs Buildmasters Ltd" title="A Professional Supply Partner" body="Cobs Buildmasters Ltd supplies construction materials and provides construction equipment rental services to builders, contractors, developers and individuals in Ghana." /><p className="mt-6 leading-8 text-muted-foreground">Our focus is clear: quality materials, reliable service and straightforward communication for every enquiry. Customers can contact us about concrete blocks, cement, iron rods and equipment requirements for their projects.</p><Button asChild variant="primary" className="mt-8"><Link to="/contact">Get in Touch <ArrowRight size={17} /></Link></Button></div><img src={siteAsset.url} alt="Construction professionals coordinating work at a Ghana building site" width={1400} height={900} loading="lazy" className="aspect-[4/3] w-full object-cover" /></div></section>
    <section className="bg-muted py-20"><div className="site-container"><SectionHeading eyebrow="Who we serve" title="Built Around Your Work" /><div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{customers.map(({ label, icon: Icon }) => <article key={label} className="border border-border bg-background p-7"><Icon className="text-accent" size={30} /><h3 className="mt-8 font-display text-2xl font-bold uppercase">{label}</h3></article>)}</div></div></section>
    <section className="bg-primary py-20 text-primary-foreground"><div className="site-container grid gap-12 lg:grid-cols-2 lg:items-center"><div><p className="eyebrow text-accent">Our identity</p><h2 className="section-title mt-3 text-primary-foreground">Materials. Equipment. Reliable Service.</h2><p className="mt-5 max-w-xl leading-8 text-primary-foreground/70">Every project begins with a sound plan and dependable inputs. Cobs Buildmasters is here to make the sourcing conversation simpler.</p></div><video src={videoAsset.url} controls muted playsInline preload="metadata" className="aspect-video w-full bg-background object-cover" aria-label="Cobs Buildmasters Ltd brand animation" /></div></section><QuoteBand /></>;
}